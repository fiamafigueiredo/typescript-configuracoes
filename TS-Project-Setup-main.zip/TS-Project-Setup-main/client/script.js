$(document).ready(function () {
    $.ajax( {
        "url": "http://localhost:3000/devices",
        "method": "GET",
        "dataType": "JSON",
        "timeout": 0,
    }).done(function (response) {
        console.log(response);
        const productContainer = $('.product-list');
        productContainer.empty();
        response.forEach(product => {
            const productElement = `
            <div class="product">
                <h3>${product.name}</h3>
                <p>${product.brand}, ${product.type}</p>
                <p> ${product.description}</p>
                <p>${product.price}</p>
            </div> `
        productContainer.append(productElement);
        });
    });
    const brandSelect = $('#brand');
    const typeSelect = $('#type');

    $.ajax( {
        "url": "http://localhost:3000/devices/brands",
        "method": "GET",
        "dataType": "JSON",
        "timeout": 0,
    }).done(function (response) {
        console.log(response);

        response.forEach((brand) => {
            const brandOption = `<option value=${brand}>${brand}</option> `
            brandSelect.append(brandOption);
        });
    });

    $.ajax( {
        "url": "http://localhost:3000/devices/brands",
        "method": "GET",
        "dataType": "JSON",
        "timeout": 0,
    }).done(function (response) {
        console.log(response);

        response.forEach((type) => {
            const typeOption = `<option value=${type}>${type}</option> `
            typeSelect.append(typeOption);
        });
    });
});

