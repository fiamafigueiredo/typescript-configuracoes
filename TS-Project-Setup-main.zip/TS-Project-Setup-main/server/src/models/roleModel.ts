enum Role {
  ADMIN = "Administrador",
  USER = "Utilizador"
}

export default Role;