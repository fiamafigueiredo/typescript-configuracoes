export interface IDevice {
    id: number;
    name: string;
    description: string;
    price: number;
    image_url: string;
    brand: string; //por exemplo, aqui e no type iria se repetir muito. Então qual a forma que eu poderia melhorar isto ? Fazer um enum?
    type: string;
}