
import { IDevice } from "../models/deviceModel.js";
import { devices } from "./../data/devicesData.js";
import { Request, Response } from "express";
import { type } from "os";

class DeviceController {
    getAll(req: Request, res: Response) {
        console.log(devices)
         return res.status(200).json(devices)
    }
    getOne() {}
    create() {}
    update() {}
    delete() {}
    getBrands(req: Request, res: Response) {
        const brands = devices.map((device) => device.brand);
        const uniqueBrands = [...new Set(brands)];
        res.json(uniqueBrands);
    }
    
    getTypes(req: Request, res: Response) {
        const types = devices.map((device) => device.type);
        const uniqueTypes = [...new Set(types)];
        res.json(uniqueTypes);
     


    }
}

export default new DeviceController;